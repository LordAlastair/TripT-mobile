angular
  .module('app.services')
  .factory('InstituicaoVeiculo', ['$resource', 'BACKEND_URL', function ($resource, BACKEND_URL) {
    return $resource(BACKEND_URL + '/instituicao-veiculo/:inv_cd_veiculo', {
      inv_cd_veiculo: '@inv_cd_veiculo'
    })
  }]);