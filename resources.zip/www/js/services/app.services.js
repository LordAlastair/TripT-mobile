angular.module('app.services', ['ngResource']);
