angular
.module('app.controllers')
.controller('HomeFornecedorCtrl', function($scope) {

});
